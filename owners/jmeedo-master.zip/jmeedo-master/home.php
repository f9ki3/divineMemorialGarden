<?php include ('header.php'); ?>

    <div class="container border body-content shadow-sm">
        <div class="p-3 mb-3">
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-3 d-flex justify-content-between align-items-center">
                        <div class="h5">Home</div>
                    </div>
                    <!-- CONTENT DIRI -->

                    <!-- CONTENT DIRI -->
                </div>
            </div>
        </div>
    </div>

    <script>

        $('#mnuHome')
            .addClass(' active')
            .attr('aria-current', 'page');

    </script>

<?php include ('footer.php'); ?>