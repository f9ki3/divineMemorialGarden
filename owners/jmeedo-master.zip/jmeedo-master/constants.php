<?php

$project_folder = '/cemetery/';

// BASE URL
define('BASE_URL', 'http://' . $_SERVER['SERVER_NAME'] . $project_folder);
define('PROJECT_NAME', "MUNICIPAL CEMETERY INFORMATION SYSTEM");
