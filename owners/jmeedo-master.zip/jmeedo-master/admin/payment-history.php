<?php include ('header.php'); ?>

    <div class="container border body-content shadow-sm">
        <div class="p-3">
            <div class="row">
                <div class="col-md-12">
                    <h5>Payment History</h5>
                </div>
            </div>
        </div>
    </div>

    <script>

        $('#mnuTaxes')
            .addClass(' active')
            .attr('aria-current', 'page');

    </script>

<?php include ('footer.php'); ?>