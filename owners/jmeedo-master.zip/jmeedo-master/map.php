<?php include ('header.php'); ?>

<div class="container border body-content shadow-sm">
    <div class="p-4 mb-3">
        <div class="row">
            <div class="col-md-12">
                <div class="mb-4">
                    <div class="h5 mb-3">Map</div>
                    <img src="includes/images/a3.jpg" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    $(function () {

        $('#mnuMap')
            .addClass(' active')
            .attr('aria-current', 'page');

    });

</script>

<?php include ('footer.php'); ?>
